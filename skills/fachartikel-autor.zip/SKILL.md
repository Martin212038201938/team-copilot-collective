---
name: fachartikel-autor
description: |
  Erstellt SEO- und GEO-optimierte Fachartikel für copilotenschule.de im React/TypeScript-Format.

  TRIGGER: Wenn der Nutzer einen neuen Wissensartikel, Fachartikel oder Blogpost für
  copilotenschule.de erstellen möchte. Auch bei Überarbeitung bestehender Artikel.

  ZIELGRUPPE: DACH-Region, Entscheider in Unternehmen (Geschäftsführer, L&D, HR, CXO, Team-/Abteilungsleiter)

  OUTPUT: React TSX-Komponente mit Schema.org, visuellen Komponenten, verifizierten Quellen, Autor-Bio
---

# Fachartikel-Autor für copilotenschule.de

Erstelle professionelle Wissensartikel die sowohl für Suchmaschinen (SEO) als auch für
KI-Systeme (GEO - Generative Engine Optimization) optimiert sind.

## Kernprinzipien

1. **Keine Textwüsten** - Visuelle Auflockerung durch Cards, Blockquotes, Checklisten, Tabellen
2. **Verifizierte Quellen** - Nur echte, überprüfbare Statistiken mit Quellenangabe
3. **Kundenorientierte FAQs** - Fragen aus Kundensicht, nicht aus Expertensicht
4. **Schema.org Markup** - @graph mit Article, FAQPage, BreadcrumbList
5. **E-E-A-T Signale** - Autor-Bio mit Expertise, Verlinkungen zu offiziellen Quellen

## Fachliche Mindestanforderungen (Pflicht)

Jeder Artikel MUSS enthalten:

1. **Definition** des Themas (max. 120 Wörter, ohne Marketing)
2. **Mindestens 3 Praxis-Szenarien** (Problem → Lösung)
3. **Implementierungs-Sektion** (konkrete Schritte/Entscheidungen im Unternehmen)
4. **Typische Fehler** (mindestens 3, inkl. Konsequenz)
5. **Entscheidungshilfe** (Wann sinnvoll / wann nicht, für Entscheider)

Fehlt einer dieser fünf Punkte, gilt der Artikel als unvollständig.

## LLM-Zitierbarkeit (Pflicht)

Jeder Artikel MUSS eine kurze Sektion enthalten:

### Kernaussagen für Entscheider

Exakt 3 Bulletpoints, jeweils:

- **Faktische Kernaussage**
- **Praktische Konsequenz**
- **Typischer Fehler**

Kurz, präzise, ohne Marketing. Ziel: Zitierbarkeit in KI-Systemen.

## Artikel-Workflow

### 1. Recherche & Quellen


**Pflichtregeln für Quellen:**
- Pro Artikel müssen **mindestens 2 unterschiedliche Quellen** aus `references/verified-sources.md` **aktiv verwendet** werden.
- Mindestens **eine Statistik MUSS** im **Statistik-Grid** erscheinen (mit Quelle).
- Wenn für ein Thema keine verifizierbaren Quellen vorhanden sind: **abbrechen** (siehe Abbruchlogik unten).

**KRITISCH**: Keine erfundenen Statistiken! Nur verifizierte Zahlen verwenden.

Siehe [references/verified-sources.md](references/verified-sources.md) für belegte Copilot-Statistiken.

Bei neuen Themen: WebSearch nutzen und Quellen dokumentieren.

### 2. Artikel-Struktur

Jeder Artikel folgt dieser Struktur:

```
1. Schnellantwort-Card (orange/gradient)
2. Hauptsektionen mit H2 (farbige Border-Bottom)
3. Visuelle Komponenten pro Sektion
4. FAQ-Sektion (kundenorientiert)
5. Quellen-Sektion (mit Links)
6. Autor-Bio
7. CTA
```

Siehe [references/article-structure.md](references/article-structure.md) für Details.

### 3. TSX-Komponente erstellen

Standard-Imports und Struktur:

```tsx
import ContentLayout from "@/components/ContentLayout";
import SEOHead from "@/components/SEOHead";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Zap, ExternalLink, Linkedin, Mail /* ... */ } from "lucide-react";
import { getAuthor, getAuthorSchemaMarkup } from "@/data/authors";
import { generateSchemaIds, generateWissenBreadcrumbItems } from "@/lib/schema";
```

Siehe [references/component-patterns.md](references/component-patterns.md) für Code-Beispiele.

### 4. Schema.org implementieren

Immer @graph mit drei Typen:

```tsx
const schema = {
  "@context": "https://schema.org",
  "@graph": [
    { "@type": "Article", /* ... */ },
    { "@type": "FAQPage", /* ... */ },
    { "@type": "BreadcrumbList", /* ... */ }
  ]
};
```

### 5. H2-Styling

Alle H2-Überschriften mit farbigem Border und Styling:

```tsx
<h2 className="text-2xl md:text-3xl font-bold pb-3 mb-6 border-b-4 border-{farbe}-500 text-{farbe}-700 dark:text-{farbe}-400">
```

Farben pro Sektion variieren: red, orange, amber, yellow, green, blue, purple, cyan, emerald, indigo

### 6. Routing & Wissen.tsx

Nach Erstellung:
1. Import in `App.tsx` hinzufügen
2. Route hinzufügen: `<Route path="/wissen/{slug}" element={<Component />} />`
3. Eintrag in `Wissen.tsx` staticKnowledgeTopics Array

## Abbruchlogik bei fehlenden Quellen (Pflicht)

Wenn für das Thema **keine verifizierbaren Quellen** (offiziell, seriös, überprüfbar) verfügbar sind:

1. **Artikel nicht schreiben** (keine hypothetischen Zahlen, keine erfundenen Zitate)
2. **Nutzer informieren**, welche Quellen fehlen bzw. welche Daten für ein sauberes Arbeiten nötig sind
3. Optional: **Alternative Themenwinkel** vorschlagen, die sich mit vorhandenen Quellen sauber belegen lassen

## Qualitätscheckliste

- [ ] Alle Statistiken haben verifizierte Quellen mit Links
- [ ] Keine Blockquotes als "Zitate" ohne echte Quelle (stattdessen: "Die Erfahrung zeigt...")
- [ ] FAQ-Fragen aus Kundenperspektive formuliert
- [ ] Autor-Bio-Sektion vorhanden
- [ ] Schema.org mit Article + FAQPage + BreadcrumbList
- [ ] H2-Überschriften visuell gestylt
- [ ] Quellen-Sektion mit klickbaren Links
- [ ] CTA am Ende
- [ ] Route in App.tsx
- [ ] Eintrag in Wissen.tsx
