# Visuelle Komponenten-Patterns

## Keine Textwüsten!

Jede Sektion sollte mindestens eine visuelle Komponente enthalten:
- Card mit Inhalten
- Statistik-Grid
- Checkliste
- Vergleichstabelle
- Blockquote
- Info-Box

## H2-Styling (Pflicht!)

Alle Hauptüberschriften mit farbigem Border:

```tsx
<h2 className="text-2xl md:text-3xl font-bold pb-3 mb-6 border-b-4 border-{farbe}-500 text-{farbe}-700 dark:text-{farbe}-400">
```

**Farbpalette** (pro Sektion variieren):
- `red` - Fehler, Risiken, Warnungen
- `orange` - Training, Enablement
- `amber` - Vorsicht, Hinweise
- `yellow` - Halluzinationen, Unsicherheit
- `green` - Erfolg, ROI, Checklisten
- `blue` - Change Management, Prozesse
- `purple` - Compliance, Rechtliches
- `cyan` - Champions, Programme
- `emerald` - Finanzen, Metriken
- `indigo` - Checklisten, Zusammenfassungen

## Statistik-Grid mit Quellen

```tsx
<Card className="my-6">
  <CardHeader>
    <CardTitle className="flex items-center gap-2 text-lg">
      <TrendingUp className="w-5 h-5 text-orange-600" />
      Titel
    </CardTitle>
  </CardHeader>
  <CardContent>
    <div className="grid md:grid-cols-3 gap-4">
      {[
        {
          metric: "72%",
          label: "kämpfen mit Alltags-Integration",
          detail: "ohne strukturiertes Training",
          color: "red",
          quelle: "Gartner Survey 2024"
        },
        {
          metric: "77%",
          label: "höhere Produktivität",
          detail: "mit professionellem Training",
          color: "green",
          quelle: "Microsoft Work Trend Index"
        },
        {
          metric: "9h",
          label: "Zeitersparnis pro Monat",
          detail: "bei trainierten Nutzern",
          color: "blue",
          quelle: "Forrester TEI Study"
        }
      ].map((stat, idx) => (
        <div key={idx} className={`p-5 border-2 border-${stat.color}-500/30 rounded-xl text-center bg-gradient-to-br from-${stat.color}-500/5 to-${stat.color}-600/10`}>
          <div className={`text-4xl font-bold text-${stat.color}-600 dark:text-${stat.color}-400`}>{stat.metric}</div>
          <div className="font-semibold mt-2">{stat.label}</div>
          <div className="text-sm text-muted-foreground mt-1">{stat.detail}</div>
          <div className="text-xs text-muted-foreground mt-2 italic">Quelle: {stat.quelle}</div>
        </div>
      ))}
    </div>
  </CardContent>
</Card>
```

## Szenario-Card (Problem/Lösung)

```tsx
<Card className="my-6 border-l-4 border-l-red-500">
  <CardHeader>
    <CardTitle className="flex items-center gap-2 text-lg">
      <AlertTriangle className="w-5 h-5 text-red-600" />
      Typisches Szenario
    </CardTitle>
  </CardHeader>
  <CardContent>
    <div className="space-y-4">
      <div className="p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
        <p className="font-semibold text-red-900 dark:text-red-100 mb-2">❌ Was passiert:</p>
        <p className="text-sm text-red-800 dark:text-red-200">
          Beschreibung des Problems
        </p>
      </div>
      <div className="p-4 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
        <p className="font-semibold text-green-900 dark:text-green-100 mb-2">✓ Die Lösung:</p>
        <ul className="text-sm text-green-800 dark:text-green-200 space-y-2">
          <li>• Lösungsschritt 1</li>
          <li>• Lösungsschritt 2</li>
        </ul>
      </div>
    </div>
  </CardContent>
</Card>
```

## Vergleichs-Grid (Richtig/Falsch)

```tsx
<Card className="my-6 border-2 border-blue-500/20">
  <CardHeader className="bg-gradient-to-r from-blue-500/10 to-blue-600/10">
    <CardTitle className="text-base">Titel</CardTitle>
  </CardHeader>
  <CardContent className="pt-6">
    <div className="grid md:grid-cols-2 gap-4">
      <div>
        <h5 className="font-semibold text-red-600 mb-2">❌ Falsch:</h5>
        <ul className="text-sm space-y-1">
          <li>• Punkt 1</li>
          <li>• Punkt 2</li>
        </ul>
      </div>
      <div>
        <h5 className="font-semibold text-green-600 mb-2">✓ Richtig:</h5>
        <ul className="text-sm space-y-1">
          <li>• Punkt 1</li>
          <li>• Punkt 2</li>
        </ul>
      </div>
    </div>
  </CardContent>
</Card>
```

## Phasen/Schritte Timeline

```tsx
<div className="space-y-6 my-6">
  {[
    {
      phase: "Phase 1: Foundation",
      zeitraum: "Woche 1-2",
      dauer: "4 Stunden",
      farbe: "blue",
      inhalte: ["Punkt 1", "Punkt 2", "Punkt 3"]
    }
    // weitere Phasen
  ].map((p, idx) => (
    <Card key={idx} className={`border-l-4 border-l-${p.farbe}-500`}>
      <CardHeader className={`bg-gradient-to-r from-${p.farbe}-500/10 to-${p.farbe}-600/5`}>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className={`text-lg text-${p.farbe}-700 dark:text-${p.farbe}-400`}>
            {p.phase}
          </CardTitle>
          <div className="flex items-center gap-4 text-sm">
            <span className="flex items-center gap-1">
              <Calendar className="w-4 h-4" /> {p.zeitraum}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" /> {p.dauer}
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        <ul className="space-y-1 text-sm">
          {p.inhalte.map((i, iidx) => (
            <li key={iidx} className="flex items-start gap-2">
              <CheckCircle2 className={`w-4 h-4 text-${p.farbe}-600 mt-0.5 flex-shrink-0`} />
              {i}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  ))}
</div>
```

## Checkliste

```tsx
<Card className="my-6">
  <CardHeader>
    <CardTitle>Checkliste</CardTitle>
  </CardHeader>
  <CardContent>
    <div className="space-y-6">
      {[
        {
          phase: "Kategorie 1",
          items: ["Aufgabe 1", "Aufgabe 2", "Aufgabe 3"]
        }
      ].map((p, idx) => (
        <div key={idx} className="p-4 border rounded-lg">
          <h4 className="font-bold text-primary mb-3">{p.phase}</h4>
          <div className="space-y-2">
            {p.items.map((item, iidx) => (
              <label key={iidx} className="flex items-center gap-3 text-sm">
                <input type="checkbox" className="rounded" />
                <span>{item}</span>
              </label>
            ))}
          </div>
        </div>
      ))}
    </div>
  </CardContent>
</Card>
```

## Quellen-Links

```tsx
<div className="grid md:grid-cols-2 gap-4">
  {[
    {
      titel: "Gartner: Copilot Impact Assessment",
      beschreibung: "Unabhängige Analyse: 72% kämpfen mit Alltags-Integration",
      url: "https://www.gartner.com/en/documents/5659223"
    }
    // weitere Links
  ].map((link, idx) => (
    <a
      key={idx}
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-start gap-3 p-4 border rounded-lg hover:border-primary/50 hover:bg-muted/50 transition-colors group"
    >
      <ExternalLink className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
      <div>
        <div className="font-semibold group-hover:text-primary transition-colors">{link.titel}</div>
        <div className="text-sm text-muted-foreground">{link.beschreibung}</div>
      </div>
    </a>
  ))}
</div>
```

## Blockquotes (Vorsicht!)

**WICHTIG**: Keine erfundenen Zitate! Zwei Optionen:

### Option 1: Erfahrungswert (ohne Anführungszeichen)

```tsx
<blockquote className="my-6 border-l-4 border-primary bg-primary/5 p-6 rounded-r-lg italic text-lg">
  Die Erfahrung zeigt: Unternehmen, die Training vernachlässigen,
  kämpfen später mit geringer Adoption und verschwendeten Lizenzen.
</blockquote>
```

### Option 2: Studie zitieren

```tsx
<blockquote className="my-6 border-l-4 border-primary bg-primary/5 p-6 rounded-r-lg italic text-lg">
  Laut Gartner schaffen nur 6% der Unternehmen den Sprung vom Pilot
  zum unternehmensweiten Rollout – ein klares Zeichen für die
  Herausforderungen bei der Copilot-Adoption.
</blockquote>
```

### NIEMALS

```tsx
// ❌ FALSCH - erfundenes Zitat!
<blockquote>
  "Governance ist kein Bremsklotz..." – Max Mustermann, CIO
</blockquote>
```
