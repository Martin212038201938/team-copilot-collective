# Artikel-Struktur für copilotenschule.de

## Grundstruktur

```
src/pages/{ArticleName}.tsx
```

## 1. Datei-Header

```tsx
import ContentLayout from "@/components/ContentLayout";
import SEOHead from "@/components/SEOHead";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Zap, AlertTriangle, Users, Target, TrendingUp,
  ExternalLink, Linkedin, Mail, CheckCircle2, XCircle
  // weitere Icons nach Bedarf
} from "lucide-react";
import { getAuthor, getAuthorSchemaMarkup } from "@/data/authors";
import { generateSchemaIds, generateWissenBreadcrumbItems } from "@/lib/schema";

const SLUG = "artikel-slug";
const PAGE_TITLE = "Artikel Titel";
```

## 2. Komponenten-Setup

```tsx
const ArticleName = () => {
  const martinLang = getAuthor('martin-lang')!;

  const ids = generateSchemaIds(SLUG, 'wissen');
  const pageUrl = `https://copilotenschule.de/wissen/${SLUG}`;
  const breadcrumbItems = generateWissenBreadcrumbItems(PAGE_TITLE, pageUrl);

  const tableOfContents = [
    { id: "section-1", title: "Erste Sektion", level: 2 },
    { id: "section-2", title: "Zweite Sektion", level: 2 },
    // ...
    { id: "faq", title: "Häufig gestellte Fragen", level: 2 },
    { id: "quellen", title: "Quellen und Links", level: 2 }
  ];

  const faqs = [
    {
      name: "Kundenorientierte Frage?",
      answer: "Antwort mit Mehrwert und ggf. Quellenverweis."
    }
    // 4-5 FAQs
  ];
```

## 3. Schema.org

```tsx
  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Article",
        "@id": ids.article,
        "headline": "Vollständiger Titel",
        "description": "Meta Description",
        "author": getAuthorSchemaMarkup(martinLang),
        "publisher": {
          "@id": "https://copilotenschule.de/#organization"
        },
        "datePublished": "2026-02-02",
        "dateModified": "2026-02-02",
        "mainEntityOfPage": {
          "@type": "WebPage",
          "@id": pageUrl
        }
      },
      {
        "@type": "FAQPage",
        "@id": ids.faq,
        "mainEntity": faqs.map(faq => ({
          "@type": "Question",
          "name": faq.name,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": faq.answer
          }
        }))
      },
      {
        "@type": "BreadcrumbList",
        "@id": ids.breadcrumb,
        "itemListElement": breadcrumbItems.map((item, index) => ({
          "@type": "ListItem",
          "position": index + 1,
          "name": item.name,
          "item": item.url
        }))
      }
    ]
  };
```

## 4. SEOHead & ContentLayout

```tsx
  return (
    <>
      <SEOHead
        title="Titel | copilotenschule.de"
        description="Meta Description (150-160 Zeichen)"
        keywords={["keyword1", "keyword2", /* 10-15 Keywords */]}
        canonicalUrl={pageUrl}
        schema={schema}
        author={martinLang}
        publishedTime="2026-02-02T10:00:00+01:00"
        modifiedTime="2026-02-02T10:00:00+01:00"
      />

      <ContentLayout
        breadcrumbs={[
          { label: "Wissen", href: "/wissen" },
          { label: "Kurztitel", href: `/wissen/${SLUG}` }
        ]}
        title="Vollständiger Artikel-Titel"
        description="Kurze Beschreibung"
        lastUpdated="02. Februar 2026"
        readTime="X Minuten"
        tableOfContents={tableOfContents}
      >
```

## 5. Schnellantwort-Card

```tsx
        <Card className="mb-8 border-2 border-orange-500/30 bg-gradient-to-br from-orange-500/5 to-amber-500/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-6 h-6 text-orange-600" />
              Schnellantwort
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-base leading-relaxed">
              <strong>Kernaussage.</strong> Weitere Details zur schnellen Orientierung.
            </p>
          </CardContent>
        </Card>
```

## 6. Sektionen mit H2

```tsx
        <section id="section-1">
          <h2 className="text-2xl md:text-3xl font-bold pb-3 mb-6 border-b-4 border-red-500 text-red-700 dark:text-red-400">
            Sektion 1: Titel
          </h2>

          <p className="mb-6">Einleitender Text.</p>

          <blockquote className="my-6 border-l-4 border-primary bg-primary/5 p-6 rounded-r-lg italic text-lg">
            "Aussage oder Erfahrungswert - KEINE erfundenen Zitate!"
          </blockquote>

          {/* Cards, Tabellen, Listen */}
        </section>
```

## 7. FAQ-Sektion

```tsx
        <section id="faq" className="mt-12 mb-12">
          <h2 className="text-2xl md:text-3xl font-bold pb-3 mb-6 border-b-4 border-slate-500 text-slate-700 dark:text-slate-400">
            Häufig gestellte Fragen (FAQ)
          </h2>

          <div className="space-y-4 my-6">
            {faqs.map((faq, idx) => (
              <Card key={idx} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold">{faq.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
```

## 8. Quellen-Sektion

```tsx
        <section id="quellen" className="mt-12 mb-12">
          <h2 className="text-2xl md:text-3xl font-bold pb-3 mb-6 border-b-4 border-slate-500 text-slate-700 dark:text-slate-400">
            Quellen und weiterführende Links
          </h2>
          <p className="text-muted-foreground mb-6">
            Studien und offizielle Ressourcen, auf die sich dieser Artikel stützt.
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            {/* Links zu Quellen - siehe verified-sources.md */}
          </div>
        </section>
```

## 9. Autor-Bio

```tsx
        <section className="my-12">
          <Card className="border-l-4 border-l-primary">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-shrink-0">
                  <img
                    src={martinLang.image}
                    alt={martinLang.name}
                    className="w-32 h-32 rounded-full object-cover border-4 border-primary/20"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2">Über den Autor</h3>
                  <div className="text-lg font-semibold text-primary mb-1">{martinLang.name}</div>
                  <div className="text-sm text-muted-foreground mb-3">{martinLang.role}</div>
                  <p className="text-sm leading-relaxed mb-4">{martinLang.bio}</p>
                  <div className="mb-3">
                    <div className="text-sm font-semibold mb-2">Expertise:</div>
                    <div className="flex flex-wrap gap-2">
                      {martinLang.expertise.map((exp, idx) => (
                        <span key={idx} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium">
                          {exp}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-3">
                    {martinLang.linkedin && (
                      <a href={martinLang.linkedin} target="_blank" rel="noopener noreferrer"
                         className="inline-flex items-center gap-2 text-sm text-primary hover:underline">
                        <Linkedin className="w-4 h-4" /> LinkedIn
                      </a>
                    )}
                    {martinLang.email && (
                      <a href={`mailto:${martinLang.email}`}
                         className="inline-flex items-center gap-2 text-sm text-primary hover:underline">
                        <Mail className="w-4 h-4" /> Kontakt
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
```

## 10. CTA

```tsx
        <div className="bg-gradient-to-r from-orange-500/10 to-amber-500/10 rounded-xl p-8 text-center my-12 border-2 border-orange-500/20">
          <h3 className="text-2xl font-bold mb-4">CTA Überschrift</h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            CTA Beschreibung
          </p>
          <a
            href="/#contact"
            className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium"
          >
            Button Text
          </a>
        </div>
      </ContentLayout>
    </>
  );
};

export default ArticleName;
```

## Routing

### App.tsx

```tsx
import ArticleName from "./pages/ArticleName";
// ...
<Route path="/wissen/artikel-slug" element={<ArticleName />} />
```

### Wissen.tsx

```tsx
{
  title: "Artikel Titel",
  description: "Kurze Beschreibung",
  link: "/wissen/artikel-slug",
  badge: "Kategorie",
  icon: "📋",
  readTime: "X Minuten",
  lastUpdated: "02. Feb. 2026"
}
```
